package com.example.localtune

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executor

private val Ink = Color(0xFF111111)
private val Panel = Color(0xFF202020)
private val Lime = Color(0xFFFA243C)
private val Muted = Color(0xFFA6A6A6)

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val mainExecutor: Executor by lazy { ContextCompat.getMainExecutor(this) }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            controller = controllerFuture?.get()
            if (hasAudioPermission()) {
                val tracks = loadTracks()
                if (tracks.isNotEmpty() && controller?.mediaItemCount == 0) {
                    controller?.setMediaItems(tracks.map { it.toMediaItem() })
                }
            }
        }, mainExecutor)
    }

    override fun onStop() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onStop()
    }

    private fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadTracks(): List<Track> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        val result = mutableListOf<Track>()
        contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: "Unknown title"
                val artist = cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
                result += Track(id, title, artist, ContentUris.withAppendedId(collection, id))
            }
        }
        return result
    }

    private fun Track.toMediaItem(): MediaItem = MediaItem.Builder()
        .setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).build())
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var tracks by remember { mutableStateOf(emptyList<Track>()) }
            var query by remember { mutableStateOf("") }
            var currentTitle by remember { mutableStateOf("Choose a track") }
            var currentArtist by remember { mutableStateOf("Your device library") }
            var playing by remember { mutableStateOf(false) }
            var position by remember { mutableLongStateOf(0L) }
            var duration by remember { mutableLongStateOf(0L) }
            var refresh by remember { mutableIntStateOf(0) }
            val audioPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { granted ->
                if (granted) {
                    tracks = loadTracks()
                    val c = controller
                    if (c != null && c.mediaItemCount == 0 && tracks.isNotEmpty()) {
                        c.setMediaItems(tracks.map { it.toMediaItem() })
                    }
                }
            }

            fun refreshLibrary() {
                if (hasAudioPermission()) {
                    tracks = loadTracks()
                    val c = controller
                    if (c != null && c.mediaItemCount == 0 && tracks.isNotEmpty()) {
                        c.setMediaItems(tracks.map { it.toMediaItem() })
                    }
                } else {
                    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                                     else Manifest.permission.READ_EXTERNAL_STORAGE
                    audioPermissionLauncher.launch(permission)
                }
            }

            DisposableEffect(controller) {
                val c = controller
                val listener = object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        currentTitle = mediaItem?.mediaMetadata?.title?.toString() ?: "Choose a track"
                        currentArtist = mediaItem?.mediaMetadata?.artist?.toString() ?: "Your device library"
                    }
                    override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        duration = c?.duration?.coerceAtLeast(0L) ?: 0L
                    }
                }
                c?.addListener(listener)
                onDispose { c?.removeListener(listener) }
            }

            LaunchedEffect(controller, refresh) {
                val c = controller
                if (c != null) {
                    while (true) {
                        position = c.currentPosition.coerceAtLeast(0L)
                        duration = c.duration.coerceAtLeast(0L)
                        playing = c.isPlaying
                        if (c.currentMediaItem != null) {
                            currentTitle = c.currentMediaItem?.mediaMetadata?.title?.toString() ?: "Unknown title"
                            currentArtist = c.currentMediaItem?.mediaMetadata?.artist?.toString() ?: "Unknown artist"
                        }
                        kotlinx.coroutines.delay(500)
                    }
                }
            }

            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Ink, surface = Panel, primary = Lime,
                    onBackground = Color.White, onSurface = Color.White
                )
            ) {
                Column(
                    Modifier.fillMaxSize().background(Ink).statusBarsPadding().navigationBarsPadding()
                        .padding(horizontal = 20.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("LOCAL TUNE", color = Lime, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text("Music on this device.", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        }
                        TextButton(onClick = { refreshLibrary(); refresh++ }) { Text("SCAN", color = Lime) }
                    }

                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search songs or artists", color = Muted) },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Lime, unfocusedBorderColor = Color(0xFF343A30),
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            cursorColor = Lime
                        )
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("SONGS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("${tracks.size} SONGS", color = Muted, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(8.dp))

                    if (tracks.isEmpty()) {
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("♪", color = Lime, fontSize = 58.sp)
                                Spacer(Modifier.height(12.dp))
                                Text("Your music library", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 19.sp)
                                Text("Scan your device to find locally stored songs.", color = Muted, fontSize = 13.sp)
                                Spacer(Modifier.height(18.dp))
                                Button(onClick = { refreshLibrary() }, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Color.White)) {
                                    Text("SCAN DEVICE")
                                }
                            }
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
                            itemsIndexed(tracks.filter {
                                it.title.contains(query, true) || it.artist.contains(query, true)
                            }) { _, track ->
                                Row(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                        .clickable {
                                            val c = controller
                                            val index = tracks.indexOf(track)
                                            if (c != null && index >= 0) {
                                                c.setMediaItems(tracks.map { it.toMediaItem() }, index, 0L)
                                                c.prepare()
                                                c.play()
                                            }
                                        }.padding(vertical = 11.dp, horizontal = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF2B171A)), contentAlignment = Alignment.Center) {
                                        Text("♪", color = Lime, fontSize = 24.sp)
                                    }
                                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                        Text(track.title, color = Color.White, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Text("▶", color = Lime, fontSize = 13.sp)
                                }
                            }
                        }
                    }

                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                            .background(Panel).padding(16.dp)
                    ) {
                        Text("PLAYING NEXT", color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Spacer(Modifier.height(7.dp))
                        Text(currentTitle, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(currentArtist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(8.dp))
                        Slider(
                            value = if (duration > 0) position.coerceAtMost(duration).toFloat() / duration else 0f,
                            onValueChange = { fraction -> position = (fraction * duration).toLong() },
                            onValueChangeFinished = { controller?.seekTo(position) },
                            colors = SliderDefaults.colors(thumbColor = Lime, activeTrackColor = Lime, inactiveTrackColor = Color(0xFF41483B))
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(formatTime(position), color = Muted, fontSize = 10.sp)
                            Text(formatTime(duration), color = Muted, fontSize = 10.sp)
                        }
                        Row(
                            Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { controller?.seekToPreviousMediaItem() }) { Text("|◀", color = Color.White, fontSize = 20.sp) }
                            Spacer(Modifier.width(22.dp))
                            Box(
                                Modifier.size(56.dp).clip(CircleShape).background(Lime).clickable {
                                    val c = controller
                                    if (c != null) {
                                        if (c.isPlaying) c.pause() else {
                                            if (c.mediaItemCount == 0 && tracks.isNotEmpty()) c.setMediaItems(tracks.map { it.toMediaItem() })
                                            c.prepare()
                                            c.play()
                                        }
                                    } else refreshLibrary()
                                }, contentAlignment = Alignment.Center
                            ) { Text(if (playing) "Ⅱ" else "▶", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
                            Spacer(Modifier.width(22.dp))
                            TextButton(onClick = { controller?.seekToNextMediaItem() }) { Text("▶|", color = Color.White, fontSize = 20.sp) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }

    private fun formatTime(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(total / 60, total % 60)
    }
}
