# LocalTune 1.1 — Android local music player

A lightweight native Android music player built with Kotlin, Jetpack Compose, and AndroidX Media3.

## Build an APK from an Android phone (cloud build)

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. Create a GitHub account or sign in at https://github.com.
2. Create a **public** repository named `LocalTune` (public repositories can use GitHub-hosted Actions without private-repository minute restrictions).
3. Upload the contents of this ZIP to the repository root. Do not upload the ZIP itself.
4. Open the repository's **Actions** tab.
5. Select **Build LocalTune APK**, then tap **Run workflow** if it has not already started after your upload.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to **Artifacts**, and download `LocalTune-debug-apk`.
8. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install it. Android may ask you to allow installs from that browser or file manager.

The workflow installs Java, Android SDK platform/build tools, and Gradle in the cloud, then builds and uploads the installable debug APK.

## Build locally
1. Install Android Studio and Android SDK Platform 35.
2. Open this project folder in Android Studio.
3. Let Gradle sync and press Run.
4. To create an APK, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## App features
- Scans music indexed by Android MediaStore on the device.
- Lists local audio tracks and searches by title or artist.
- Play, pause, previous, next, and seek controls.
- Media3 playback service for background playback and Android media-session integration.
- Requests the appropriate audio permission for the Android version.
- No streaming account or network access required for local music playback.

## Notes
- This is Android source code with a cloud build workflow, not a prebuilt APK.
- The library uses Android MediaStore. Files not indexed by MediaStore may not appear.
- This workflow creates a debug APK. It is suitable for personal installation/testing, not Play Store publishing.
- Application ID: `com.example.localtune`
- Version: `1.1`
